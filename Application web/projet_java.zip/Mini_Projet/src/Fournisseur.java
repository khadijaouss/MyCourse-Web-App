
public class Fournisseur extends Personne {
	
	private String specialite;
	
	public Fournisseur(int ident, String nomsocial, String adresse, String specialite) {
		super(ident, nomsocial, adresse);
		this.specialite = specialite;
	}

	public Fournisseur(Personne personne, String specialite) {
		super(personne);  
		this.specialite = specialite;
	}
	
	
	
	public String getSpecialite(){
		return this.specialite;
	}
	public void setSpecialite(String specialite){
		this.specialite = specialite;
	}
	
	
	@Override
	 public void affiche() {}
	
	
	

}



