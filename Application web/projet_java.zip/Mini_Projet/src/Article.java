
public class Article {
	private int reference;
	private String designation;
	private double prixunitaire;
	private int quantitestock;
	
	//constructor
	public Article(int reference, String designation, double prixunitaire, int quantitestock) {
		this.reference = reference;
		this.designation = designation;
		this.prixunitaire = prixunitaire;
		this.quantitestock = quantitestock;
	}
	
	
	
	//constructor by copy
	public Article(Article a) {
		reference = a.reference;
		designation = a.designation;
		prixunitaire = a.prixunitaire;
		quantitestock = a.quantitestock;
	}


	public int getReference() {
		return this.reference;
	}
	public void setReference(int reference) {
		this.reference = reference; 
	}
	public String getDesignation() {
		return this.designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation; 
	}
	public double getPrixunitaire() {
		return this.prixunitaire;
	}
	public void setPrixunitaire(double prixunitaire) {
		this.prixunitaire = prixunitaire; 
	}
	public int getQuantitestock() {
		return this.quantitestock;
	}
	public void setQuantitestock(int quantitestock) {
		this.quantitestock = quantitestock; 
	}
	public void affiche() {
		System.out.printf(" %d) %s prix unitaire : %f quantit� : %d \n",reference, designation, prixunitaire, quantitestock);
	}
	
	
	

}
