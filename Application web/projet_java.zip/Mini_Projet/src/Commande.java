

public class Commande {
	private int numcomm;
	private String datecomm;
	private Client client;
	
	public Commande(int numcomm, String datecomm, Client client) {
		this.numcomm = numcomm;
		this.datecomm = datecomm;
		this.client = client;
	}
	
	
	public int getNumcomm() {
		return this.numcomm;
	}
	public void setNumcomm(int numcomm) {
		this.numcomm= numcomm; 
	}
	public String getDatecomm() {
		return this.datecomm;
	}
	public void setDatecomm(String datecomm) {
		this.datecomm = datecomm; 
	}
	public Client getClient() {
		return this.client;
	}
	public void setNumcomm(Client client) {
		this.client = client; 
	}
	
	public void affiche() {
		System.out.printf(" %d) Commande de Mr/Mme %s, son ID = '%d'  _Date 10/10/10 \n",numcomm,client.getNomsocial(),client.getIdent());
	}
	
	
}
