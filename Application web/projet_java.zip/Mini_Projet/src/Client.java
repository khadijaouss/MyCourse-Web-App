
public class Client extends Personne {
	
	private double chiffreaffaire;
	
	public Client(int ident, String nomsocial, String adresse, double chiffreaffaire) {
		super(ident, nomsocial, adresse);
		this.chiffreaffaire = chiffreaffaire;
		
	}
	
	public double getChiffreAffaire(){
		return this.chiffreaffaire;
	}
	public void setChiffreAffaire(double chiffreaffaire){
		this.chiffreaffaire = chiffreaffaire;
	}
	
	@Override
	 public void affiche() {
		System.out.printf(" %d) Nom:  %s Adresse : %s Chiffre d'affaire : %f \n",ident,nomsocial,adresse,chiffreaffaire);
	}
	
	
}
