
import java.util.*;
import java.util.Scanner;
import java.util.Vector;


public class Commerciale {
	
	private static Vector<Ligne> lignes = new Vector<Ligne>();
	
	private static Vector<Client> clients = new Vector<Client>();
	
	private static Vector<Commande> commandes = new Vector<Commande>();
	
	private static Vector<Article> articles = new Vector<Article>();
	
	
	public static void Passercommande(Commande c) {
		
		commandes.add(new Commande(c.getNumcomm(), c.getDatecomm(), c.getClient()));
		
	}
	
	public static void Annulercommande(Commande c) {
		
		commandes.remove(c);
		
	}
	public static void AjouterArticle(Article a) {
		
		articles.add(new Article(a.getReference(), a.getDesignation(), a.getPrixunitaire(), a.getQuantitestock()));	
	
	}
	public static void SupprimerArticle(Article a) {
		
		articles.remove(a);
		
	}
	public static void AjouterClient(Client cl) {
		
		clients.add(new Client(cl.ident, cl.nomsocial, cl.getAdresse(), cl.getChiffreAffaire()));	
		
	}
	public static void SupprimerClient(Client cl) {
		
		clients.remove(cl);
		
	}
	
	public static void AjouterLigne(Commande c, Article a, int quantite) {
		
		lignes.add(new Ligne(c, a, quantite));
	}
	public static void SupprimerLigne(Commande c, Article a, int quantite) {
		
		//lignes.remove();
	}
	

	
//#######################################################
//#######################################################
	
	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		
		
		int reference = 0; // identifiant de l'article
		int ident = 0; // identifiant du client
		int numcomm = 0; // identifiant du client
		String action;
		String choice;
		String choice1 = ""; //choix pour boucle
		String choice2 = ""; //choix pour boucle
		String choice3 = ""; //choix pour boucle
		String choice4 = ""; //choix pour boucle
		String choice5 = ""; //choix pour boucle
		String choice6 = ""; //choix pour boucle
		boolean exist = false;
		String choix="2";
		String choix2="2";
		boolean revenir2;
		String choix3="2";
		boolean revenir3=false;
		String valeur2="";
		String valeur22="";
		String valeur3="";
		String valeur33="";
		String valeur6="";
		String valeur66="";
		boolean v =true;
		boolean vv =true;
		boolean v6 =true;
		
		String choixx;
		Article articleAchercher = null;
		Client clientAchercher = null;
		//Commande commandeForDelete = null;
		//int numcommandeForDelete;
		String sortie = "";
		boolean revenir = false;
		String sortir="";
		String retour="";
		String retour1 = "";
		boolean fin = false;
		int quantiteRestant;
		
		
		
		do {
		
		
		do {
			System.out.println("---------Gestion commercial--------------");
			System.out.println("1) Ajouter un article");
			System.out.println("2) Supprimer un article");
			System.out.println("3) Ajouter un client");
			System.out.println("4) Supprimer un client");
			System.out.println("5) Passer une commande");
			System.out.println("6) Annuler une commande");
			System.out.println("0) Quitter");
			System.out.println("\n");
			System.out.println("Entrez un choix : ");
			
			choice = scan.next();
			
			switch(choice){
				case "1" : {
			
					do {
						reference++;
						
						System.out.println("----Avant l'ajout de l'article----");
						if(articles.size()==0) {
							System.out.println("La liste des articles est vide... ");
							
						}else {
							System.out.println("Liste des articles : ");
							for(Article a : articles) {
								a.affiche();
							}
							System.out.printf(" Taille : %d \n",articles.size());
						}
						
						String designation;
						System.out.println("Donnez la designation de l'article � ajouter : ");
						designation = scan.next();
						
						double prixunitaire;
						System.out.println("Donnez son prix unitaire : ");
						prixunitaire = scan.nextDouble();
						
						int quantitestock;
						System.out.println("Donnez la quantit� en stock : ");
						quantitestock = scan.nextInt();
						
						Article a = new Article(reference,designation,prixunitaire, quantitestock);
						AjouterArticle(a);
						
						
						System.out.println("\n-----Ajout de l'article-----");
						System.out.printf(" Demarrage de l'ajout... \n Article '%d' a �t� ajout� ",reference);
						System.out.println("\n\n-----Apr�s l'ajout-----");
						System.out.println("Liste des articles : ");
						
						for(Article b : articles) {
							b.affiche();
						}
						System.out.printf(" Taille : %d \n",articles.size());
					
						
						System.out.println(" Voulez vous ajouter un autre article (oui/non) ? : ");
						choice1 = scan.next();
						 
					}while(choice1.equals("oui"));
						
						break;
				} 
				case "2" : {
					int referenceForDelete;
					Article articleForDelete;
					boolean verify;
					choice2="non";
					do {
						choice2="non";
						System.out.println("----Avant la suppression----");
						if(articles.size()==0) {
							System.out.println("La liste des articles est vide... ");
							System.out.println("Voulez-vous retourner au Menu (oui/non)? : ");
							valeur2 = scan.next();
						}else {
							System.out.println("Liste des articles : ");
							for(Article a : articles) {
								a.affiche();
							}
							System.out.printf(" Taille : %d \n",articles.size());
							//#########bloqu�
							do {
								verify = false;
								revenir2=false;
								
								System.out.println("Tapez l'id de larticle � supprimer : ");
								referenceForDelete = scan.nextInt();
								articleForDelete = null;
								for(Article b : articles) {
									if(b.getReference()==referenceForDelete) {
										articleForDelete = b;
										verify = true;
									}
								}
								if(verify == false) {
									System.out.printf(" L'article '%d' n'existe pas \n", referenceForDelete);
									System.out.println("Tapez (r) pour reprendre votre choix ou une autre touche pour retourner au menu...");
									choix2 = scan.next();
									if(choix2!="r")
										revenir2 = true;
								}
								if(verify==true && choix2.equals("r"))
									break;
								}while(choix2.equals("r"));
								
								if(revenir2==true) {break;}
								//##
								System.out.println(" Demarrage de la suppression");
								
								
								SupprimerArticle(articleForDelete);
								System.out.printf("L'article '%d' a �t� supprim�e \n", referenceForDelete);
								System.out.println("----Apr�s la suppression----");
								
								if(articles.size()==0) {
									System.out.println("La liste des articles est vide... ");
									System.out.println("Voulez-vous retourner au Menu (oui/non)? : ");
									valeur2 = scan.next();
									
								}else {
									System.out.println(" Liste des articles : ");
									for(Article c : articles) {
										c.affiche();
									}
									vv=false;
									System.out.printf(" Taille : %d \n",articles.size());
									System.out.println("Voulez-vous supprimer un autre article (oui/non)? : ");
									choice2 = scan.next();
									
								}		
						}
						
						if(valeur2.equals("oui")) {
							choice2="non";
						}else if(choice2.equals("oui")) {
							vv=true;
						}else if(articles.size()!=0 && choice2!="oui") {
							break;
						}else{
							valeur22 = "non";
							break;
						}
						
					 
					}while(choice2.equals("oui"));
					break;	
				}
				case "3" : {
					do {
						ident++;
						
						
						System.out.println("----Avant l'ajout du client----");
						if(clients.size()==0) {
							System.out.println("La liste des clients est vide... ");
						}else {
							System.out.println("Liste des clients: ");
							for(Client cl : clients) {
								cl.affiche();
							}
							System.out.printf(" Taille : %d \n",clients.size());
						}
						String nom;
						System.out.println("Donnez le Nom du client � ajouter : ");
						nom = scan.next();
						
						String adresse;
						System.out.println("Donnez son adresse : ");
						adresse = scan.next();
						
						double chiffreAffaire;
						System.out.println("Donnez son chiffre d'affaire : ");
						chiffreAffaire = scan.nextDouble();
						
						Client a = new Client(ident,nom,adresse, chiffreAffaire);
						AjouterClient(a);
						System.out.println("\n-----Ajout du Client-----");
						System.out.printf(" Demarrage de l'ajout... \n Client '%d' a �t� ajout� ",ident);
						System.out.println("\n\n-----Apr�s l'ajout-----");
						System.out.println("Liste des clients : ");
						
						for(Client b : clients) {
							b.affiche();
						}
						System.out.printf(" Taille : %d \n",clients.size());
					
						System.out.println(" Voulez vous ajouter un autre client (oui/non) ? : ");
						choice3 = scan.next();
						 
					}while(choice3.equals("oui"));
						
						break;
				} 
				case "4" : {
					int identForDelete;
					Client clientForDelete;
					boolean verify;
					
					
					choice4="non";
					do {
						choice4="non";
						System.out.println("----Avant la suppression----");
						if(clients.size()==0) {
							System.out.println("La liste des clients est vide... ");
							System.out.println("Voulez-vous retourner au Menu (oui/non)? : ");
							valeur3 = scan.next();
						}else {
							System.out.println("Liste des clients : ");
							for(Client a : clients) {
								a.affiche();
							}
							System.out.printf(" Taille : %d \n",clients.size());
							
							do {
								revenir3 = false;
								System.out.println("Tapez l'id du client � supprimer : ");
								identForDelete = scan.nextInt();
								
								clientForDelete = null;
								verify = false;
								for(Client b : clients) {
									if(b.getIdent()==identForDelete) {
										clientForDelete = b;
										verify = true;
									}
								}
								if(verify == false) {
									System.out.printf(" Le client '%d' n'existe pas \n", identForDelete);
									System.out.println("Tapez (r) pour reprendre votre choix ou une autre touche pour retourner au menu...");
									choix3 = scan.next();
									if(choix3!="r")
										revenir3 = true;
								}
								if(verify==true && choix3.equals("r"))
									break;
								}while(choix3.equals("r"));
								if(revenir3==true) {break;}
								System.out.println(" Demarrage de la suppression");
								SupprimerClient(clientForDelete);
								System.out.printf("Le client '%d' a �t� supprim�e \n", identForDelete);
								System.out.println("----Apr�s la suppression----");
								if(clients.size()==0) {
									System.out.println("La liste des clients est vide... ");
									System.out.println("Voulez-vous retourner au Menu (oui/non)? : ");
									valeur3 = scan.next();
								}else {
									System.out.println(" Liste des clients : ");
									for(Client c : clients) {
										c.affiche();
									}
									v=false;
									System.out.printf(" Taille : %d \n",clients.size());
									System.out.println("Voulez-vous supprimer un autre client (oui/non)? : ");
									choice4 = scan.next();
									
								}
							
						}
						
						if(valeur3.equals("oui")) {
							choice4="non";
						}else if(choice4.equals("oui")){
							v=true;
						}else if(clients.size()!=0 && choice4!="oui") {
							break;
						}else {
							valeur33 = "non";
							break;
						} 
						
					 
					}while(choice4.equals("oui"));
					break;	
				} 
				
				
				
				case "5" : {
					do {
						
						numcomm++;
						
						System.out.println("----Avant l'ajout du commande----");
						
						if(commandes.size()==0) {
							System.out.println("La liste des commandes est vide ");
						}else {
							System.out.println("Liste des commandes : ");
							//afficher les commandes enregistr�es
							for(Commande a : commandes) {
								a.affiche();
							}
							System.out.printf(" Taille : %d \n",commandes.size());
						}
						
						
						if(clients.size()==0) {
							System.out.println("Il n'y a pas de client enregistr�, veuillez ajoutez d'abord le client dans le menu 3");
						
						}else {
							System.out.printf("Choisissez parmis les clients, celui qui souhaite passer la commande...\n");
							for(Client cl : clients) {
								cl.affiche();
							}
							
							do{
								//determination du client
							
							int id;
							System.out.println("Donnez l'identifiant du client qui veux passer une commande : ");
							id= scan.nextInt();
							
							//Client clientAchercher = null;
							boolean verify = false;
							
							for(Client b : clients) {
								if(b.getIdent()==id) {
									clientAchercher = b;
									verify = true;
									
								}
							}
							retour1="faux";
							if(verify == false) {
								System.out.printf(" Ce client '%d' n'existe pas \n", id);
								System.out.println("Tapez (r) pour reprendre votre choix ou une autre touche pour retourner au Menu : ");
								choix = scan.next();
								if(choix!="r") {
									retour1 = "vrai";
								}
							}
							if(verify==true && choix.equals("r"))
								break;
							}while(choix.equals("r"));
							if(retour1=="vrai") {break;}
							
							
							if(articles.size()==0) {
								System.out.println("Il n'y a pas d'article enregistr�, veuillez ajoutez d'abord les articles dans le menu 1");
								
							}else {
								System.out.printf("Choisissez parmis les articles, celui que le client souhaite commander...\n");
								for(Article art : articles) {
									art.affiche();
								}
								
								do {
								int idArticle;
								System.out.println("Choisissez l'article � commander en donnant son identifiant : ");
								idArticle = scan.nextInt();
								
								//Article articleAchercher = null;
								boolean verifyy = false;
								
								for(Article a : articles) {
									if(a.getReference()==idArticle) {
										articleAchercher = a;
										verifyy = true;
										
									}
								}
								retour1 = "faux";
								if(verifyy == false) {
									System.out.printf(" L'article '%d' n'existe pas \n", idArticle);
									System.out.println("Tapez (r) pour reprendre votre choix ou une autre touche pour retourner au Menu : ");
									choix = scan.next();
									if(choix!="r") {
										retour1 ="vrai";
									}
								}
								if(verifyy==true && choix.equals("r"))
									break;
								}while(choix.equals("r"));
								if(retour1=="vrai") {break;}
								
								int quantitecomm;
								System.out.println("Donnez la quantit� � commander : ");
								quantitecomm = scan.nextInt();
								if(quantitecomm>articleAchercher.getQuantitestock()) {
									System.out.println("D�sol� quantit� non disponible...");
									System.out.println("<Revenir au menu ? fournisseur> ?");
								}else {
									Date date = new Date();
									String str = String.format("%tc", date );
							
									Commande c = new Commande(numcomm,str,clientAchercher);
									Article acopy = new Article(articleAchercher);
									
									Passercommande(c);
									
									AjouterLigne(c, acopy, quantitecomm);
									
									System.out.println("\n-----Ajout de la commande-----");
									System.out.printf(" Demarrage de l'ajout... \n Commande '%d' a �t� ajout� ",numcomm);
									System.out.println("\n\n-----Apr�s l'ajout-----");
									System.out.println("Liste des commandes: ");
									for(Commande b : commandes) {
										b.affiche();
									}
									System.out.printf(" Taille : %d \n",commandes.size());
									
									quantiteRestant = articleAchercher.getQuantitestock()-quantitecomm;
									articleAchercher.setQuantitestock((quantiteRestant));
									
									if(articleAchercher.getQuantitestock()==0) {
										SupprimerArticle(articleAchercher);
										if(articles.size()==0)
											System.out.println("Il n'y a plus d'article en stock... ");
											exist=false;
									}else {
										exist = true;
									}
									
								}
								
							}
						}
						
						if(exist==true) {
							System.out.println(" Voulez vous ajouter une autre commande (oui/non) ? : ");
							choice5 = scan.next();
						}else {
							System.out.println(" Allez au Menu ? (oui/non) : ");
							choice5 = scan.next();
							if(choice5.equals("oui")) {
								break;
							}else {
								retour = "vrai";
							}
							
						}
						
						
					}while(choice5.equals("oui"));
						
					break;
				}
				
				case "6" : {
					int numcommandeForDelete;
					Commande commandeForDelete;
					boolean verify;
					choice6="non";
					do {
						choice6="non";
						System.out.println("----Avant la suppression----");
						if(commandes.size()==0) {
							System.out.println("La liste des commandes est vide...");
							System.out.println("Voulez-vous retournez au Menu (oui/non) ? : ");
							valeur6 = scan.next();
						}else {
							System.out.println("Liste des commandes : ");
							//afficher les commandes enregistr�es
							for(Commande co : commandes) {
								co.affiche();
							}
							System.out.printf(" Taille : %d \n",commandes.size());
							
							do {
								revenir=false;
								
								
								System.out.println("Tapez l'id de la commande � supprimer : ");
								
								numcommandeForDelete = scan.nextInt();
								
								commandeForDelete = null;
								verify = false;
								
								
								for(Commande com : commandes) {
									if(com.getNumcomm()==numcommandeForDelete) {
										commandeForDelete = com;
										verify = true;
									}
								}
								
								if(verify == false) {
									System.out.printf(" La commande '%d' n'existe pas \n", numcommandeForDelete);
									System.out.println("Tapez (r) pour reprendre votre choix ou une autre touche pour retourner au Menu : ");
									choix = scan.next();
									if(choix!="r")
										revenir = true;	
								}
								if(verify==true && choix.equals("r"))
									break;
								
								}while(choix.equals("r"));
								if(revenir == true) {break;}
								System.out.println(" Demarrage de la suppression");
								Annulercommande(commandeForDelete);
								System.out.printf("La commande '%d' a �t� supprim�e \n", numcommandeForDelete);
								//SupprimmerLigne();
								System.out.println("----Apr�s la suppression----");
								
								if(commandes.size()==0) {
									System.out.println("Liste des commandes est vide...");
									System.out.println("Voulez-vous retourner au Menu (oui/non)? : ");
									valeur6 = scan.next();
								}else {
									System.out.println(" Liste des commandes: ");
									for(Commande c : commandes) {
										c.affiche();
									}
									v6=false;
									System.out.printf(" Taille : %d \n",commandes.size());
									System.out.println("Voulez-vous supprimer une autre commande (oui/non)? : ");
									choice6 = scan.next();
								}
							
						}
						 
						if(valeur6.equals("oui")) {
							choice6="non";
						}else if(choice6.equals("oui")){
							v6=true;
						}else if(commandes.size()!=0 && choice6!="oui") {
							break;
						}else {
							valeur66 = "non";
							break;
						} 
						
						}while(choice6.equals("oui"));
						
					break;
					
				}
				
				default : {
					fin = true;
					break;
				}
			}
			
			
			if(sortir=="non") {break;}
			
			
		}while(choice=="1" || choice == "2" || choice == "3" || choice == "4" || choice == "5" || choice == "6"); 
		
		if(valeur22=="non") {break;}
		if(valeur33 == "non") {break;}
		if(valeur66 == "non") {break;}
		if(retour == "vrai") {break;}
		if(sortie == "oui") {break;}
		if(fin==true) {break;}
		System.out.println("Revenir au menu (oui/non) ?");	
		action = scan.next();
		
		}while(action.equals("oui"));	
		
		scan.close();
		System.out.println("Fin du programme...");
		
	}//main
	
}//class


/*
 
 System.out.println("----Avant la suppression----");
						if(commandes.size()==0) {
							System.out.println("La liste des commandes est vide ");
							System.out.println("Voulez-vous retournez au Menu (oui/non) ? : ");
							choice6 = scan.next();
							if(choice6.equals("oui")) {
								break;
							}else {
								sortie = "oui";
							}
							
						}else {
							System.out.println("Liste des commandes : ");
							//afficher les commandes enregistr�es
							for(Commande co : commandes) {
								co.affiche();
							}
							System.out.printf(" Taille : %d \n",commandes.size());
							
							do {
								
							
								System.out.println("Tapez l'id de la commande � supprimer : ");
								
								numcommandeForDelete = scan.nextInt();
								
								commandeForDelete = null;
								verify = false;
								
								for(Commande com : commandes) {
									if(com.getNumcomm()==numcommandeForDelete) {
										commandeForDelete = com;
										verify = true;
									}
								}
								if(verify == false) {
									System.out.printf(" La commande '%d' n'existe pas \n", numcommandeForDelete);
									System.out.println("Tapez (1) pour reprendre votre choix ou une autre touche pour retourner au Menu : ");
									choix = scan.next();
									if(choix!="1") {
										revenir = true;
										break;
									}
								}	
							}while(choix.equals("1"));
							if(revenir = true) {
								break;
							}else {
								System.out.println(" Demarrage de la suppression");
								Annulercommande(commandeForDelete);
								System.out.printf("La commande '%d' a �t� supprim�e \n", numcommandeForDelete);
								//SupprimmerLigne();
								System.out.println("----Apr�s la suppression----");
								if(commandes.size()==0) {
									System.out.println("Liste des commandes est vide...");
									System.out.println("Revenir au Menu (oui/non) ? : ");
									choice6 = scan.next();
									if(choice6!="oui") {
										sortir = "non";
										break;
									}else {sortir = "oui";}
								}else {
									System.out.println(" Liste des commandes: ");
									for(Commande c : commandes) {
										c.affiche();
									}
									System.out.printf(" Taille : %d \n",commandes.size());
									System.out.println("Voulez-vous supprimer une autre commande (oui/non)? : ");
									choice6 = scan.next();
								}
								if(sortir=="oui") {break;}
								
							}
							
						}
  
 */
 



