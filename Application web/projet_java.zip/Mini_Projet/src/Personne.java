
abstract public class Personne {
	//variables
	protected int ident;
	protected String nomsocial;
	protected String adresse;
	
	//Constructor
	protected Personne(int ident, String nomsocial, String adresse) {
		this.ident = ident;
		this.nomsocial = nomsocial;
		this.adresse = adresse;
	}
	
	//Constructor by copy
		protected Personne(Personne personne) {
			ident = personne.ident;
			nomsocial = personne.nomsocial;
			adresse = personne.adresse;
		}
	
	//getters and setters
	protected int getIdent() {
		return this.ident;
	}
	protected void setIdent(int ident) {
		this.ident = ident; 
	}
	protected String getNomsocial() {
		return this.nomsocial;
	}
	protected void setNomsocial(String nomsocial) {
		this.nomsocial = nomsocial; 
	}
	protected String getAdresse() {
		return this.adresse;
	}
	protected void setAdresse(String adresse) {
		this.adresse = adresse; 
	}
	
	//print
	protected abstract void affiche();
	
	
	

}
